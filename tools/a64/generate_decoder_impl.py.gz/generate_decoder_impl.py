#!/usr/bin/env python3
"""Generate Voland's initial A64 decoder from the pinned Arm AARCHMRS data."""
from __future__ import annotations
import argparse
import gzip
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
SPEC = ROOT / "core/cpu/a64/spec/AARCHMRS-2026-09-A64-supported.json.gz"
HEADER = ROOT / "core/cpu/a64/insn.h"

# Initial instruction families already implemented by the interpreter. The
# spec still supplies every concrete 32/64-bit encoding form for these IDs.
SUPPORTED = {
    "HINT", "SVC", "B_uncond", "BL", "B_cond", "CBZ", "CBNZ", "BR", "RET",
    "ADR", "ADRP", "MOVN", "MOVZ", "MOVK", "MADD", "MSUB", "UDIV",
    "SDIV", "CCMN_reg", "CSEL", "CSINC", "CSINV", "CSNEG", "SBFM",
    "UBFM", "ADD_addsub_imm", "SUB_addsub_imm", "ADDS_addsub_imm",
    "SUBS_addsub_imm", "ADD_addsub_shift", "SUB_addsub_shift",
    "ADDS_addsub_shift", "SUBS_addsub_shift", "AND_log_shift",
    "ORR_log_shift", "EOR_log_shift", "ANDS_log_shift", "BIC_log_shift",
    "ORN_log_shift", "EON", "LDR_imm_gen", "STR_imm_gen", "MRS",
}

# Operand masks use RD/RN/RM/RA bits 0..3. Register-31 interpretation is
# NONE=0, SP=1, ZERO=2. Memory kind: none=0, load=1, store=2, load+store=3.
# Block kind: sequential=0, direct=1, conditional=2, call=3, indirect=4,
# SVC=5, exception=6, system=7, barrier=8.
CANONICAL = {"BL": "B_uncond"}

META = {
    "HINT": (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "SVC": (0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0),
    "B_uncond": (0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0),
    "B_cond": (0,0,0,0,0,0,15,0,0,0,0,0,0,0,2,0,0),
    "CBZ": (1,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,0),
    "CBNZ": (1,0,2,0,0,0,0,0,0,0,0,0,0,0,2,0,0),
    "BR": (2,0,0,2,0,0,0,0,0,0,0,0,0,0,4,0,0),
    "RET": (2,0,0,2,0,0,0,0,0,0,0,0,0,0,4,0,0),
    "ADR": (0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "ADRP": (0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "MOVN": (0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "MOVZ": (0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "MOVK": (1,1,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "MADD": (14,1,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0),
    "MSUB": (14,1,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0),
    "UDIV": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "SDIV": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "CCMN_reg": (6,0,0,2,2,0,15,15,0,0,0,0,0,0,0,0,0),
    "CSEL": (6,1,2,2,2,0,15,0,0,0,0,0,0,0,0,0,0),
    "CSINC": (6,1,2,2,2,0,15,0,0,0,0,0,0,0,0,0,0),
    "CSINV": (6,1,2,2,2,0,15,0,0,0,0,0,0,0,0,0,0),
    "CSNEG": (6,1,2,2,2,0,15,0,0,0,0,0,0,0,0,0,0),
    "SBFM": (2,1,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "UBFM": (2,1,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "ADD_addsub_imm": (2,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "SUB_addsub_imm": (2,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
    "ADDS_addsub_imm": (2,1,2,1,0,0,0,15,0,0,0,0,0,0,0,0,0),
    "SUBS_addsub_imm": (2,1,2,1,0,0,0,15,0,0,0,0,0,0,0,0,0),
    "ADD_addsub_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "SUB_addsub_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "ADDS_addsub_shift": (6,1,2,2,2,0,0,15,0,0,0,0,0,0,0,0,0),
    "SUBS_addsub_shift": (6,1,2,2,2,0,0,15,0,0,0,0,0,0,0,0,0),
    "AND_log_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "ORR_log_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "EOR_log_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "ANDS_log_shift": (6,1,2,2,2,0,0,15,0,0,0,0,0,0,0,0,0),
    "BIC_log_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "ORN_log_shift": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "EON": (6,1,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0),
    "LDR_imm_gen": (2,1,2,1,0,0,0,0,0,0,1,0,1,1,0,0,0),
    "STR_imm_gen": (3,0,2,1,0,0,0,0,0,0,2,0,1,1,0,0,0),
    "MRS": (0,1,2,0,0,0,0,0,0,0,0,0,0,0,7,0,0),
}


def ident(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").upper()

def load_rows():
    with gzip.open(SPEC, "rt", encoding="utf-8") as f:
        doc = json.load(f)
    meta = doc.get("_meta", {})
    version = meta.get("version", {})
    if version.get("ref") != "2026-09_rel" or version.get("schema") != "2.9.6":
        raise SystemExit("pinned AARCHMRS source version/schema mismatch")
    if not isinstance(doc.get("forms"), list):
        raise SystemExit("pinned source does not contain the selected A64 form list")
    rows = []
    for node in doc["forms"]:
        source_opid = node.get("operation_id")
        opid = CANONICAL.get(source_opid, source_opid)
        name = node.get("name")
        if source_opid not in SUPPORTED:
            raise SystemExit(f"unexpected operation ID in pinned source: {source_opid}")
        if node.get("condition") != {"_type":"AST.Bool", "value":True}:
            raise SystemExit(f"unsupported nontrivial condition in {name}")
        mask = value = 0
        fields = {}
        for enc in node["encoding"]["values"]:
            r = enc["range"]
            start, width = r["start"], r["width"]
            pattern = enc["value"]["value"].strip("'")
            if len(pattern) != width or not re.fullmatch(r"[01x]+", pattern):
                raise SystemExit(f"bad encoding pattern in {name}: {pattern}")
            fields[enc.get("name", "")] = (start, width)
            for idx, bit in enumerate(pattern):
                pos = start + width - 1 - idx
                if bit in "01":
                    mask |= 1 << pos
                    if bit == "1":
                        value |= 1 << pos
        rows.append({"opid":opid,"name":name,"mask":mask,"value":value,"fields":fields})
    rows.sort(key=lambda r: (r["opid"], r["name"]))
    found = {r["opid"] for r in rows}
    missing = {CANONICAL.get(op, op) for op in SUPPORTED} - found
    if missing:
        raise SystemExit("missing supported operation IDs: " + ", ".join(sorted(missing)))
    rows.sort(key=lambda r: (r["opid"], r["name"]))
    for i, a in enumerate(rows):
        for b in rows[i+1:]:
            if ((a["value"] ^ b["value"]) & (a["mask"] & b["mask"])) == 0:
                raise SystemExit(f"overlapping decode patterns: {a['name']} and {b['name']}")
    return rows


def bits_expr(fields, name, enc="encoding"):
    if name not in fields:
        return "0u"
    start, width = fields[name]
    mask = (1 << width) - 1
    return f"(({enc} >> {start}u) & UINT32_C(0x{mask:x}))"


def imm_expr(row):
    f = row["fields"]
    op = row["opid"]
    if op in ("ADR", "ADRP"):
        return f"(({bits_expr(f,'immhi')} << 2u) | {bits_expr(f,'immlo')})"
    if op in ("SBFM", "UBFM"):
        return f"(({bits_expr(f,'immr')} << 6u) | {bits_expr(f,'imms')})"
    for name in ("imm26", "imm19", "imm16", "imm12", "imm9", "imm6"):
        if name in f:
            e = bits_expr(f, name)
            if op in ("MOVN", "MOVZ", "MOVK"):
                return f"({e} << ({bits_expr(f,'hw')} * 16u))"
            if op in ("ADD_addsub_imm", "SUB_addsub_imm", "ADDS_addsub_imm", "SUBS_addsub_imm"):
                return f"({e} << ({bits_expr(f,'sh')} * 12u))"
            if op in ("LDR_imm_gen", "STR_imm_gen"):
                return f"({e} << {bits_expr(f,'size')})"
            return e
    return "0u"


def aux_expr(row):
    f = row["fields"]
    parts = []
    if "sf" in f: parts.append(f"({bits_expr(f,'sf')} << 0u)")
    if "size" in f: parts.append(f"({bits_expr(f,'size')} << 1u)")
    if row["opid"] == "B_uncond": parts.append(f"({bits_expr(f,'op')} << 3u)")
    if "shift" in f: parts.append(f"({bits_expr(f,'shift')} << 4u)")
    if "cond" in f: parts.append(f"({bits_expr(f,'cond')} << 6u)")
    if "hw" in f: parts.append(f"({bits_expr(f,'hw')} << 10u)")
    if "nzcv" in f: parts.append(f"({bits_expr(f,'nzcv')} << 12u)")
    return " | ".join(parts) if parts else "0u"


def reg_expr(fields, names):
    for name in names:
        if name in fields:
            return bits_expr(fields, name)
    return "0u"


def make_header(opids):
    enums = ["  A64_OP_INVALID = 0,", "  A64_OP_UNDEFINED,"]
    for i, opid in enumerate(opids, start=2):
        enums.append(f"  A64_OP_{ident(opid)} = {i},")
    enums.append(f"  A64_OP_COUNT = {len(opids)+2}")
    return '''#ifndef VOLAND_CPU_A64_INSN_H
#define VOLAND_CPU_A64_INSN_H

#include <stdint.h>

typedef enum A64_Op {
''' + "\n".join(enums) + '''
} A64_Op;

typedef struct A64_Insn {
    uint16_t op;
    uint8_t rd, rn;
    uint8_t rm, ra;
    uint16_t aux;
    /* Normalized immediate: branch displacements are signed byte offsets;
     * ADR/ADRP are signed, move-wide/add immediates are pre-shifted,
     * load/store offsets are byte-scaled, and bitfields pack immr:imms. */
    uint64_t imm;
} A64_Insn;

_Static_assert(sizeof(A64_Insn) == 16,
               "A64 instruction records must be 16 bytes");

enum {
    A64_FIELD_RD = 1u << 0,
    A64_FIELD_RN = 1u << 1,
    A64_FIELD_RM = 1u << 2,
    A64_FIELD_RA = 1u << 3,
    A64_REG31_NONE = 0,
    A64_REG31_SP = 1,
    A64_REG31_ZERO = 2,
    A64_MEM_NONE = 0,
    A64_MEM_LOAD = 1,
    A64_MEM_STORE = 2,
    A64_MEM_LOAD_STORE = 3,
    A64_KIND_SEQUENTIAL = 0,
    A64_KIND_DIRECT_BRANCH = 1,
    A64_KIND_CONDITIONAL_BRANCH = 2,
    A64_KIND_CALL = 3,
    A64_KIND_INDIRECT_BRANCH = 4,
    A64_KIND_SVC = 5,
    A64_KIND_EXCEPTION = 6,
    A64_KIND_SYSTEM = 7,
    A64_KIND_BARRIER = 8,
    A64_AUX_IS_64 = 1u << 0,
    A64_AUX_SIZE_SHIFT = 1,
    A64_AUX_SIZE_MASK = 3u << A64_AUX_SIZE_SHIFT,
    A64_AUX_LINK = 1u << 3,
    A64_AUX_SHIFT_SHIFT = 4,
    A64_AUX_COND_SHIFT = 6,
    A64_AUX_HW_SHIFT = 10,
    A64_AUX_NZCV_SHIFT = 12
};

/* mem_size=0 means per-form size is in A64_Insn.aux; alignment is bytes. */
typedef struct A64_Op_Info {
    uint8_t gpr_reads;
    uint8_t gpr_writes;
    uint8_t rd31_use;
    uint8_t rn31_use;
    uint8_t rm31_use;
    uint8_t ra31_use;
    uint8_t flags_read;
    uint8_t flags_written;
    uint8_t vreg_reads;
    uint8_t vreg_writes;
    uint8_t mem_kind;
    uint8_t mem_size;
    uint8_t mem_count;
    uint8_t mem_alignment;
    uint8_t kind;
    uint8_t fp_mode_dependent;
    uint8_t jit_tier;
} A64_Op_Info;

extern const A64_Op_Info A64_OP_INFO[];
extern const uint32_t A64_OP_INFO_COUNT;

#endif
'''


def make_source(rows, opids):
    opnum = {op:i+2 for i,op in enumerate(opids)}
    lines = ['/* Generated by tools/a64/generate_decoder.py; do not edit. */',
             '#include "cpu/a64/decoder.h"', '#include <stddef.h>', '',
             'typedef struct A64_Decode_Pattern {',
             '    uint32_t mask;', '    uint32_t value;', '    uint16_t op;',
             '    uint8_t rd_shift, rd_width;', '    uint8_t rn_shift, rn_width;',
             '    uint8_t rm_shift, rm_width;', '    uint8_t ra_shift, ra_width;',
             '    uint8_t imm_kind;', '    uint8_t aux;', '    uint8_t imm_shift0, imm_width0;',
             '    uint8_t imm_shift1, imm_width1;',
             '} A64_Decode_Pattern;', '',
             'static const A64_Decode_Pattern k_patterns[] = {']
    for r in rows:
        f=r['fields']
        def pos(names):
            for n in names:
                if n in f: return f[n]
            return (0,0)
        rd=pos(('Rd','Rt')); rn=pos(('Rn',)); rm=pos(('Rm',)); ra=pos(('Ra',))
        # Immediate descriptors are retained for the semantic extraction path.
        if r['opid'] in ('ADR','ADRP'): imms=[f['immhi'],f['immlo']]
        elif r['opid'] in ('SBFM','UBFM'): imms=[f['immr'],f['imms']]
        else:
            imms=[]
            for n in ('imm26','imm19','imm16','imm12','imm9','imm6'):
                if n in f: imms=[f[n]]; break
        imms=(imms+[ (0,0),(0,0)])[:2]
        # aux stores static per-form attributes. Dynamic fields are also encoded
        # into the final A64_Insn.aux at decode time below.
        aux=0
        if 'sf' in f and f['sf'][1]==1: aux |= ((r['value'] >> f['sf'][0]) & 1)
        if r['opid'] in ('LDR_imm_gen','STR_imm_gen') and 'size' in f:
            aux |= ((r['value'] >> f['size'][0]) & ((1 << f['size'][1]) - 1)) << 1
        vals=[r['mask'],r['value'],opnum[r['opid']],rd[0],rd[1],rn[0],rn[1],rm[0],rm[1],ra[0],ra[1],0,aux,imms[0][0],imms[0][1],imms[1][0],imms[1][1]]
        lines.append('    {'+', '.join(f'UINT32_C(0x{x:x})' if i<2 else str(x) for i,x in enumerate(vals))+'}, /* '+r['name']+' */')
    lines += ['};','', 'const A64_Op_Info A64_OP_INFO[A64_OP_COUNT] = {',
              '    [A64_OP_UNDEFINED] = { .kind = A64_KIND_EXCEPTION },']
    for op in opids:
        m=META[op]
        names=['gpr_reads','gpr_writes','rd31_use','rn31_use','rm31_use','ra31_use','flags_read','flags_written','vreg_reads','vreg_writes','mem_kind','mem_size','mem_count','mem_alignment','kind','fp_mode_dependent','jit_tier']
        vals=', '.join(f'.{n} = {v}' for n,v in zip(names,m) if v)
        lines.append(f'    [A64_OP_{ident(op)}] = {{ {vals} }},')
    lines += ['};','', 'const uint32_t A64_OP_INFO_COUNT = A64_OP_COUNT;', '',
              'static uint32_t extract(uint32_t word, uint8_t shift, uint8_t width) {',
              '    if (width == 0u) return 0u;',
              '    return (word >> shift) & ((UINT32_C(1) << width) - 1u);', '}', '',
              'bool a64_decode(uint32_t encoding, A64_Insn *out) {',
              '    if (out == NULL) return false;',
              '    for (uint32_t i = 0; i < (uint32_t)(sizeof(k_patterns)/sizeof(k_patterns[0])); ++i) {',
              '        const A64_Decode_Pattern *p = &k_patterns[i];',
              '        if ((encoding & p->mask) != p->value) continue;',
              '        A64_Insn decoded = {0};',
              '        decoded.op = p->op;',
              '        decoded.rd = (uint8_t)extract(encoding,p->rd_shift,p->rd_width);',
              '        decoded.rn = (uint8_t)extract(encoding,p->rn_shift,p->rn_width);',
              '        decoded.rm = (uint8_t)extract(encoding,p->rm_shift,p->rm_width);',
              '        decoded.ra = (uint8_t)extract(encoding,p->ra_shift,p->ra_width);',
              '        decoded.aux = p->aux;',
              '        *out = decoded;',
              '        return true;',
              '    }',
              '    return false;',
              '}','']
    # Pattern entries are non-overlapping by construction. The record's aux
    # field packs the small instruction attributes shared by interpreter/JIT.
    lines[lines.index('        *out = decoded;')] = '        *out = decoded;'
    # Dynamic attributes are derived from the exact fields defined by the
    # selected AARCHMRS encoding form.
    insert_at = lines.index('        decoded.aux = p->aux;') + 1
    lines[insert_at:insert_at] = [
        '        if (p->op == A64_OP_B_UNCOND) decoded.aux |= (uint16_t)(extract(encoding,31u,1u) << 3u);',
        '        if (p->op == A64_OP_ADD_ADDSUB_SHIFT || p->op == A64_OP_SUB_ADDSUB_SHIFT || p->op == A64_OP_ADDS_ADDSUB_SHIFT || p->op == A64_OP_SUBS_ADDSUB_SHIFT || p->op == A64_OP_AND_LOG_SHIFT || p->op == A64_OP_ORR_LOG_SHIFT || p->op == A64_OP_EOR_LOG_SHIFT || p->op == A64_OP_ANDS_LOG_SHIFT || p->op == A64_OP_BIC_LOG_SHIFT || p->op == A64_OP_ORN_LOG_SHIFT || p->op == A64_OP_EON) decoded.aux |= (uint16_t)(extract(encoding,22u,2u) << A64_AUX_SHIFT_SHIFT);',
        '        if (p->op == A64_OP_B_COND || p->op == A64_OP_CCMN_REG || p->op == A64_OP_CSEL || p->op == A64_OP_CSINC || p->op == A64_OP_CSINV || p->op == A64_OP_CSNEG) decoded.aux |= (uint16_t)(extract(encoding,12u,4u) << A64_AUX_COND_SHIFT);',
        '        if (p->op == A64_OP_MOVN || p->op == A64_OP_MOVZ || p->op == A64_OP_MOVK) decoded.aux |= (uint16_t)(extract(encoding,21u,2u) << A64_AUX_HW_SHIFT);',
        '        if (p->op == A64_OP_CCMN_REG) decoded.aux |= (uint16_t)(extract(encoding,0u,4u) << A64_AUX_NZCV_SHIFT);',
        '        decoded.imm = 0u;',
        '        if (p->imm_width0 != 0u) decoded.imm = extract(encoding,p->imm_shift0,p->imm_width0);',
        '        if (p->imm_width1 != 0u) decoded.imm = (decoded.imm << p->imm_width1) | extract(encoding,p->imm_shift1,p->imm_width1);',
        '        if (p->op == A64_OP_B_UNCOND) decoded.imm = (uint64_t)(((decoded.imm ^ (UINT64_C(1) << 25u)) - (UINT64_C(1) << 25u)) * 4u);',
        '        if (p->op == A64_OP_B_COND || p->op == A64_OP_CBZ || p->op == A64_OP_CBNZ) decoded.imm = (uint64_t)(((decoded.imm ^ (UINT64_C(1) << 18u)) - (UINT64_C(1) << 18u)) * 4u);',
        '        if (p->op == A64_OP_ADR || p->op == A64_OP_ADRP) decoded.imm = (uint64_t)((decoded.imm ^ (UINT64_C(1) << 20u)) - (UINT64_C(1) << 20u));',
        '        if (p->op == A64_OP_MOVN || p->op == A64_OP_MOVZ || p->op == A64_OP_MOVK) decoded.imm <<= extract(encoding,21u,2u) * 16u;', 
        '        if (p->op == A64_OP_ADD_ADDSUB_IMM || p->op == A64_OP_SUB_ADDSUB_IMM || p->op == A64_OP_ADDS_ADDSUB_IMM || p->op == A64_OP_SUBS_ADDSUB_IMM) decoded.imm <<= extract(encoding,22u,1u) * 12u;',
        '        if (p->op == A64_OP_LDR_IMM_GEN || p->op == A64_OP_STR_IMM_GEN) decoded.imm <<= extract(encoding,30u,2u);',
    ]
    return '\n'.join(lines)


def make_vectors(rows, opids):
    opnum={op:i+2 for i,op in enumerate(opids)}
    out=['/* Generated by tools/a64/generate_decoder.py; do not edit. */',
         'static const struct A64_Decoder_Vector { uint32_t encoding; uint16_t op,aux; uint8_t rd,rn,rm,ra; uint64_t imm; } k_a64_decoder_vectors[] = {']
    for r in rows:
        f=r['fields']; enc=r['value']
        def get(names):
            for n in names:
                if n in f:
                    s,w=f[n];return (enc>>s)&((1<<w)-1)
            return 0
        rd=get(('Rd','Rt'));rn=get(('Rn',));rm=get(('Rm',));ra=get(('Ra',))
        op=r['opid']; imm=0
        if op in ('ADR','ADRP'): imm=(get(('immhi',))<<2)|get(('immlo',))
        elif op in ('SBFM','UBFM'): imm=(get(('immr',))<<6)|get(('imms',))
        else:
            for n in ('imm26','imm19','imm16','imm12','imm9','imm6'):
                if n in f: imm=get((n,)); break
            if op in ('MOVN','MOVZ','MOVK'): imm <<= get(('hw',))*16
            if op in ('ADD_addsub_imm','SUB_addsub_imm','ADDS_addsub_imm','SUBS_addsub_imm'): imm <<= get(('sh',))*12
            if op in ('LDR_imm_gen','STR_imm_gen'): imm <<= get(('size',))
        aux=0
        if 'sf' in f: aux |= get(('sf',))
        if op == 'B_uncond': aux |= get(('op',)) << 3
        if op in ('LDR_imm_gen','STR_imm_gen'): aux |= get(('size',)) << 1
        if op == 'B_uncond': imm = ((imm ^ (1 << 25)) - (1 << 25)) * 4
        elif op in ('B_cond','CBZ','CBNZ'): imm = ((imm ^ (1 << 18)) - (1 << 18)) * 4
        elif op in ('ADR','ADRP'): imm = (imm ^ (1 << 20)) - (1 << 20)
        out.append(f'    {{ UINT32_C(0x{enc:08x}), {opnum[op]}, {aux}, {rd}, {rn}, {rm}, {ra}, UINT64_C(0x{imm & ((1<<64)-1):x}) }}, /* {r["name"]} */')
    out += ['};','']
    return '\n'.join(out)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--output-dir',type=pathlib.Path,required=True)
    args=parser.parse_args()
    rows=load_rows(); opids=sorted({r['opid'] for r in rows})
    if set(opids)!=set(META):
        raise SystemExit('metadata map does not exactly match generated operations')
    args.output_dir.mkdir(parents=True,exist_ok=True)
    outputs={HEADER:make_header(opids),
             args.output_dir/"decoder_generated.c":make_source(rows,opids),
             args.output_dir/"a64_decoder_vectors_generated.h":make_vectors(rows,opids)}
    failed=False
    for path,content in outputs.items():
        content=content+'\n' if not content.endswith('\n') else content
        # The public ABI header is checked in and must never be rewritten by a build.
        if path == HEADER or args.check:
            if not path.exists() or path.read_text(encoding='utf-8')!=content:
                print(f'out of date: {path.relative_to(ROOT) if path.is_relative_to(ROOT) else path}',file=sys.stderr);failed=True
        else:
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_text(content,encoding='utf-8')
    if failed: raise SystemExit(1)
    print(f'{"verified" if args.check else "generated"} {len(rows)} A64 forms across {len(opids)} operation IDs')

if __name__=='__main__': main()
